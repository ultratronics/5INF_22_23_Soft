﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace snake
{
    public partial class Form1 : Form
    {
        snake bob;
        Graphics paper;
        Pen pen = new Pen(Color.Black, 2);
        blokje eten;
        public Form1()
        {
            InitializeComponent();
            KeyPreview = true;
        }
        public void tekenSnake() { 
        
        for (int i= 0; i < bob.slang.Count; i++)
            {
                paper.DrawRectangle(pen, bob.slang.ElementAt(i).x, bob.slang.ElementAt(i).y, 50,50);

            }
        
        }


        private void btnBegin_Click(object sender, EventArgs e)
        {
            
          
            paper.DrawRectangle(pen, 0, 0, 400, 400);
            

            List<blokje> lijst = new List<blokje>();

            lijst.Add(new blokje(100, 100));
            lijst.Add(new blokje(150, 100));
            lijst.Add(new blokje(200, 100));

            bob = new snake(3, lijst, Richting.Omlaag);
            
            tekenSnake();

            timer1.Enabled = true;
        }



        struct snake
        {
            public List<blokje> slang;
            public int levens;
            public Richting kop;
            public snake(int levens,List<blokje> slang, Richting kop)
            {
                this.levens = levens;
                this.slang = slang;
                this.kop = kop;
            }

        }

        struct blokje
        {
            public blokje(int x, int y)
            {
               this.x = x;
               this.y = y;
            }
            public int x;
            public int y;

            
        }

        public void UpdateSnakeHead()
        {
            int headX = bob.slang[bob.slang.Count - 1].x;
            int headY = bob.slang[bob.slang.Count - 1].y;
            // Bepaal de nieuwe positie van de slangkop op
            //basis van de huidige richting
            switch (bob.kop)
            {
                case Richting.Boven:
                    headY -= 50;
                    break;
                case Richting.Omlaag:
                    headY += 50;
                    break;
                case Richting.Links:
                    headX -= 50;
                    break;
                case Richting.Rechts:
                    headX += 50;
                    break;
            }
            blokje newHead = new blokje(headX, headY);
            bob.slang.RemoveAt(bob.slang.Count - 1);
            bob.slang.Insert(bob.slang.Count, newHead);
        }


        public void opschuiven() { 
        
            for (int i = 0;i < bob.slang.Count-1; i++)
            {

               int tmpx = bob.slang.ElementAt(i + 1).x;
               int tmpy = bob.slang.ElementAt(i + 1).y;

                blokje tmpblk = new blokje(tmpx, tmpy);

                bob.slang.RemoveAt(i);
                bob.slang.Insert(i, tmpblk);
            }


        
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            opschuiven();
            UpdateSnakeHead();

            if (bob.slang.ElementAt(bob.slang.Count - 1).x == eten.x && bob.slang.ElementAt(bob.slang.Count - 1).y == eten.y) {

                Random random = new Random();

                int tmp = random.Next(1, 10) * 50;
                int tmp2 = random.Next(1, 10) * 50;
                eten = new blokje(tmp, tmp2);

                int tmpxprev = bob.slang.ElementAt(0).x;
                int tmpyprev = bob.slang.ElementAt(0).y;

                opschuiven();
                bob.slang.Insert(0, new blokje(tmpxprev, tmpyprev));
                UpdateSnakeHead();
                

            }


            paper.Clear(Color.White);
            tekenSnake();
            DrawFood();
        }

        private void btnopschuiven_Click(object sender, EventArgs e)
        {
            opschuiven();
            UpdateSnakeHead();
            


            paper.Clear(Color.White);
            tekenSnake();
        }
        enum Richting
        {
            Boven,
            Omlaag,
            Links,
            Rechts
        }
        private void Knopdown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Z:
                    bob.kop = Richting.Boven;
                    label1.Text = "boven";
                    break;
                case Keys.S:
                    bob.kop = Richting.Omlaag;
                    label1.Text = "omlaag";

                    break;
                case Keys.Q:

                    bob.kop = Richting.Links;
                    label1.Text = "links";

                    break;
                case Keys.D:
                    bob.kop = Richting.Rechts;
                    label1.Text = "rechts";

                    break;
            }

        }

        public void DrawFood()
        {
            paper.DrawEllipse(pen, eten.x, eten.y, 50, 50);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            paper = pictureBox1.CreateGraphics();
            Random random = new Random();

            int tmp = random.Next(1,10) * 50;
            int tmp2 = random.Next(1, 10) * 50;
            eten = new blokje(tmp, tmp2);
            DrawFood();
        }
    }
}
