using RestSharp;

namespace test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        async private void Form1_Load(object sender, EventArgs e)
        {
            var options = new RestClientOptions("http://145.145.145.5/index.php")
            {
                MaxTimeout = -1,
            };
            var client = new RestClient(options);
            var request = new RestRequest("", Method.Post);
            request.AlwaysMultipartFormData = true;
            request.AddParameter("welkekaart", "15");
            RestResponse response = await client.ExecuteAsync(request);
            Console.WriteLine(response.Content);
        }

    }
}